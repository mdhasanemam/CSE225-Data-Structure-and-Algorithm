#include"iostream"
using namespace std;

struct node
{
    int data;
    node *next;
};
void display(node *h)
{
    while(h!=NULL)
    {
        cout<<h->data<<" ";
        h=h->next;
    }
    cout<<endl;
}
void deletehead(node *h)
{
    node *temp=h;
    h=h->next;
   delete temp;
}
int main()
{
    node *head=NULL,*temp,*newnode;
    int x,n;
    cin>>n;

    for(int i=0; i<n; i++)
    {
        cin>>x;
        newnode= new node;
        newnode->data=x;
        newnode->next=NULL;

        if(head==NULL)
        {
            head=newnode;
            temp=head;
        }
        else
        {
          temp->next=newnode;
          temp=newnode;
        }
    }

    display(head);
   deletehead(head);
    display(head);
}


