#include"iostream"
using namespace std;
struct node
{
    int data;
    node *next;
};
void searchlinkedlist(node *h,int item)
{
    node *temp=h;
    int falg=0;
    while(temp!=NULL)
    {
        if(temp->data==item)
        {
            falg=1;
            break;
        }
        temp= temp->next;

    }

    if(falg==1)
    {
        cout<<"Item Found"<<endl;
    }
    else
    {
        cout<<"Item not Found"<<endl;
    }
}
int main()
{
    node *head=NULL,*temp,*newnode;
    int x,n;
    cin>>n;

    for(int i=0; i<n; i++)
    {
        cin>>x;
        newnode=new node;
        newnode->data=x;
        newnode->next=NULL;

        if(head==NULL)
        {
            head=newnode;
            temp=head;
        }
        else
        {
            temp->next=newnode;
            temp=newnode;
        }
    }
    searchlinkedlist(head,5);
    searchlinkedlist(head,6);
}

