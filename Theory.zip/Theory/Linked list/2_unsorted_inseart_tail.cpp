#include"iostream"
using namespace std;
struct node
{
    int data;
    node *next;
};
void display(node *h)
{
    node *temp=h;
    while(temp!=NULL)
    {
        cout<<temp->data<<" ";
        temp=temp->next;
    }
    cout<<endl;
}
void insertail(node *&h,int item)
{
    node *n=new node;
    n->data=item;
    n->next=NULL;
    if(h==NULL)
    {
        h=n;
       return;
    }

    node *temp =h;
    while(temp->next!=NULL)
    {
        temp=temp->next;
    }
    temp->next=n;
}
int main()
{
    node *head=NULL,*temp,*newnode;
    int x,n;
    cin>>n;

    for(int i=0;i<n;i++)
    {
        cin>>x;
     newnode=new node;
     newnode->data=x;
     newnode->next=NULL;

     if(head==NULL)
     {
         head=newnode;
         temp=head;
     }
     else
     {
         temp->next=newnode;
         temp=newnode;

     }

    }
    display(head);
    insertail(head,6);
     display(head);

}
