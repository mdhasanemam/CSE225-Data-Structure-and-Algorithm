#include"iostream"
using namespace std;

struct node
{
    int data;
    node *next;
};
void display(node *h)
{
    while(h!=NULL)
    {
        cout<<h->data<<" ";
        h=h->next;
    }
    cout<<endl;
}
void deletehead(node *&h)
{
    node *temp=h;
    h=h->next;
    delete temp;
}
void deletetail(node *&h)
{

    node *temp=h;

    while(temp->next->next!=NULL)
    {
        temp=temp->next;
    }
    node *temp2=temp->next;
    delete temp2;
    temp->next=NULL;
}
void deletetmid(node *&h, int pos)
{

    node *temp=h;

    for(int i=1; i<pos-1; i++)
    {
        temp=temp->next;
    }
    node *temp2=temp->next;
    temp->next=temp2->next;
    delete temp2;

}

void deletetbyvalue(node *&h, int value)
{

    if(h->data==value)
    {
        node *temp3=h;
        h=h->next;
        delete temp3;
    }
    node *temp=h;
    while(temp->next!=NULL && temp->next->data!=value)
    {
        temp=temp->next;
    }
    if(temp->next!=NULL)
    {
        node *temp2=temp->next;
        temp->next=temp2->next;
        delete temp2;
    }
}
int main()
{
    node *head=NULL,*temp,*newnode;
    int x,n;
    cin>>n;

    for(int i=0; i<n; i++)
    {
        cin>>x;
        newnode= new node;
        newnode->data=x;
        newnode->next=NULL;

        if(head==NULL)
        {
            head=newnode;
            temp=head;
        }
        else
        {
            temp->next=newnode;
            temp=newnode;
        }
    }

    display(head);
    deletehead(head);
    display(head);
    deletetmid(head,3);
    display(head);
    deletetail(head);
    display(head);
    deletetbyvalue(head,2);
    display(head);

}



