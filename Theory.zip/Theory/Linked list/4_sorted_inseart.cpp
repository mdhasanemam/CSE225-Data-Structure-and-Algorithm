#include"iostream"
using namespace std;

struct node
{
    int data;
    node *next;
};
void display(node *h)
{
    while(h!=NULL)
    {
        cout<<h->data<<" ";
        h=h->next;
    }
    cout<<endl;
}
void shortinsert(node *&h,int item)
{
    node *n=new node;
    n->data=item;
    if(h==NULL || item<h->data)
    {
      n->next=h;
      h=n;
      return;
    }

    node *temp=h;

    while(temp->next!=NULL && temp->next->data<item)
    {
        temp=temp->next;
    }
    n->next=temp->next;
    temp->next=n;

}

int main()
{
    node *head=NULL,*temp,*newnode;
    int x,n;
    cin>>n;

    for(int i=0; i<n; i++)
    {
        cin>>x;
        newnode= new node;
        newnode->data=x;
        newnode->next=NULL;

        if(head==NULL)
        {
            head=newnode;
            temp=head;
        }
        else
        {
          temp->next=newnode;
          temp=newnode;
        }
    }

    display(head);
   shortinsert(head,3);
    display(head);
}

