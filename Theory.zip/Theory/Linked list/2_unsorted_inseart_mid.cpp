#include"iostream"
using namespace std;

struct node
{
    int data;
    node *next;
};
void display(node *h)
{
    while(h!=NULL)
    {
        cout<<h->data<<" ";
        h=h->next;
    }
    cout<<endl;
}
void insertmid(node *&h,int item,int pos)
{
    node *temp= h;
    for(int i=1; i<pos-1; i++)
    {
        temp=temp->next;
    }
    node *n= new node;
    n->data=item;
    n->next=temp->next;
    temp->next=n;
}

int main()
{
    node *head=NULL,*temp,*newnode;
    int x,n;
    cin>>n;

    for(int i=0; i<n; i++)
    {
        cin>>x;
        newnode= new node;
        newnode->data=x;
        newnode->next=NULL;

        if(head==NULL)
        {
            head=newnode;
            temp=head;
        }
        else
        {
          temp->next=newnode;
          temp=newnode;
        }
    }

    display(head);
    insertmid(head,3,3);
    display(head);
}
