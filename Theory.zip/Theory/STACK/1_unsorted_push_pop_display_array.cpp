#include"iostream"
using namespace std;
void display(int arr[],int top)
{
    for(int i=0; i<=top; i++)
    {
        cout<< arr[i]<<" ";
    }
    cout<<endl;
}

void push(int arr[],int n,int &top,int item)
{
    if(top==n-1)
    {
        cout<<"stack is full"<<endl;
    }
    else
    {
        top++;
        arr[top]=item;
    }
}
void pop(int &top)
{
    if(top<0)
    {
        cout<<"Stack is empty"<<endl;
    }
    else
    {
        top--;
    }

}

void popbyvalue(int arr[],int &top,int item)
{
    int index=-1;
    int i;
    for(i=0; i<=top; i++)
    {
        if(arr[i]==item)
        {
            index=i;
            break;
        }
    }
    if(index==-1)
    {
        cout<<"Item Not foud"<<endl;
    }
    else
    {
        for(int i=index; i<top; i++)
        {
            arr[i]=arr[i+1];
        }
        (top)--;
    }
}

void popbyposition(int arr[],int &top,int pos)
{
    if(pos<0 || pos>top)
    {
        cout<<"Invalid"<<endl;
    }
    for(int i=pos;i<top;i++)
    {
        arr[i]=arr[i+1];
    }
    top--;
}
int main()
{
    int n,x;
    cin>>n;
    int arr[n];
    int top=-1;

    for(int i=0; i<n; i++)
    {
        cin>>x;
        push(arr,n,top,x);
    }

    display(arr,top);
    popbyvalue(arr,top,2);
    display(arr,top);
    popbyposition(arr,top,2);
    display(arr,top);
    pop(top);
    display(arr,top);
}
