#include"iostream"
using namespace std;
struct node
{
    int data;
    node *next;
};
void display(node *top)
{
    while(top!=NULL)
    {
        cout<<top->data<<" ";
        top=top->next;
    }
    cout<<endl;
}

void push(node *&top,int item)
{
     node* n=new node;
    n->data=key;

    if(top==NULL || key<top->data)
    {
        n->next=top;
        top=n;
        return;
    }

    node* temp=top;

    while(temp->next!=NULL && temp->next->data<key)
    {
        temp=temp->next;
    }

    n->next=temp->next;
    temp->next=n;
}
void pop( node *&top)
{
    if(top==NULL)
    {
        cout<< "Empty"<<endl;
    }
    node *temp=top;
    top=top->next;
    delete temp;

}

void popbyvalue(node *&top,int item)
{
    if(top==NULL)
    {
        cout<< "Empty"<<endl;
    }

    if(top->data==item)
    {
        node *temp=top;
        top=top->next;
        delete temp;
    }

    node *temp2=top;
    while(temp2->next!=NULL && temp2->next->data!=item)
    {
        temp2=temp2->next;
    }
    if(temp2->next==NULL)
    {
        cout<<"Value not found"<<endl;
    }
    node *temp3=temp2->next;
    temp2->next=temp3->next;
    delete temp3;
}

void popbyposition(node *&top,int pos)
{
    if(top==NULL)
    {
        cout<< "Empty"<<endl;
    }

    node *temp=top;
    for(int i=1; i<pos-1 && temp->next!=NULL; i++)
    {
        temp=temp->next;
    }
    node *temp2=temp->next;
    temp->next=temp2->next;
    delete temp2;
}
int main()
{
    node *top=NULL;
    int n,x;
    cin>>n;

    for(int i=0; i<n; i++)
    {
        cin>>x;
        push(top,x);
    }
    display(top);

    popbyposition(top,4);
    display(top);
    popbyvalue(top,2);
    display(top);
    pop(top);
    display(top);
}




