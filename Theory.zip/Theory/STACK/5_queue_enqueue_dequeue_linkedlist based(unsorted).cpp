#include"iostream"
using namespace std;

struct node
{
    int data;
    node* next;
};

void display(node* front)
{
    while(front!=NULL)
    {
        cout<<front->data<<" ";
        front=front->next;
    }
    cout<<endl;
}

void enqueue(node* &front,node* &rear,int item)
{
    node* n=new node;
    n->data=item;
    n->next=NULL;

    if(front==NULL)
    {
        front=n;
        rear=n;
    }
    else
    {
        rear->next=n;
        rear=n;
    }
}

void dequeue(node* &front,node* &rear)
{
    if(front==NULL)
    {
        cout<<"Queue is empty"<<endl;
    }
    else
    {
        node* temp=front;
        front=front->next;
        delete temp;

        if(front==NULL)
        {
            rear=NULL;
        }
    }
}

void dequeuebyvalue(node* &front,node* &rear,int item)
{
    if(front==NULL)
    {
        cout<<"Queue is empty"<<endl;
        return;
    }

    if(front->data==item)
    {
        dequeue(front,rear);
        return;
    }

    node* temp=front;

    while(temp->next!=NULL && temp->next->data!=item)
    {
        temp=temp->next;
    }

    if(temp->next==NULL)
    {
        cout<<"Item is not found"<<endl;
    }
    else
    {
        node* temp2=temp->next;
        temp->next=temp2->next;

        if(temp2==rear)
        {
            rear=temp;
        }

        delete temp2;
    }
}

void dequeuebyposition(node* &front,node* &rear,int pos)
{
    if(front==NULL)
    {
        cout<<"Queue is empty"<<endl;
        return;
    }

    if(pos==1)
    {
        dequeue(front,rear);
        return;
    }

    node* temp=front;

    for(int i=1;i<pos-1 && temp->next!=NULL;i++)
    {
        temp=temp->next;
    }

    if(temp->next==NULL)
    {
        cout<<"Invalid Position"<<endl;
    }
    else
    {
        node* temp2=temp->next;
        temp->next=temp2->next;

        if(temp2==rear)
        {
            rear=temp;
        }

        delete temp2;
    }
}

int main()
{
    node *front=NULL,*rear=NULL;

    int n,x;
    cin>>n;

    for(int i=0;i<n;i++)
    {
        cin>>x;
        enqueue(front,rear,x);
    }

    display(front);

    dequeuebyvalue(front,rear,2);
    display(front);

    dequeuebyposition(front,rear,2);
    display(front);

    dequeue(front,rear);
    display(front);
}
