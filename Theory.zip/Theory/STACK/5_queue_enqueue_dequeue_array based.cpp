#include"iostream"
using namespace std;
void display(int arr[],int front, int &rear)
{

    for(int i=front; i<=rear; i++)
    {
        cout<< arr[i]<<" ";
    }
    cout<<endl;
}

void  enqueue(int arr[],int size,int &rear,int item)
{
    if(rear==size-1)
    {
        cout<<"Queue is full"<<endl;
    }
    else
    {
        rear++;
        arr[rear]=item;
    }
}
void dequeue(int &front,int rear)
{
    if(front>rear)
    {
        cout<<"Queue is empty"<<endl;
    }
    else
    {
        front++;
    }
}
void dequeuebyvlaue(int arr[],int front,int &rear,int item)
{
    if(front>rear)
    {
        cout<<"Queue is empty"<<endl;
    }
    int index=-1;
    for(int i=front; i<=rear; i++)
    {
        if(arr[i]==item)
        {
            index=i;
            break;
        }
    }
    if(index==-1)
    {
        cout<<"Item is not found"<<endl;
    }
    else
    {
        for(int i=index; i<rear; i++)
        {
            arr[i]=arr[i+1];
        }
        rear--;
    }
}

void dequeuebyposition(int arr[],int front,int &rear,int pos)
{
    if(front>rear)
    {
        cout<<"Queue is empety"<<endl;
    }
    for(int i=pos; i<rear; i++)
    {
        arr[i]=arr[i+1];
    }
    rear--;

}
int main()
{
    int front=0,rear=-1;
    int n,x;
    cin>>n;
    int arr[n];

    for(int i=0; i<n; i++)
    {
        cin>>x;
        enqueue(arr,n,rear,x);
    }
    display(arr,front,rear);
    dequeuebyvlaue(arr,front,rear,2);
    display(arr,front,rear);
    dequeuebyposition(arr,front,rear,2);
    display(arr,front,rear);
     dequeue(front,rear);
    display(arr,front,rear);
}

