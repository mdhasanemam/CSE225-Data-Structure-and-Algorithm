#include"iostream"
using namespace std;
void display(int arr[],int n)
{
    for(int i=0; i<n; i++)
    {
        cout<<arr[i]<<" ";
    }
    cout<<endl;
}

int deletebyvalue(int arr[],int *n,int item)
{
    int index=-1;
    for(int i=0; i<*n; i++)
    {
        if(arr[i]==item)
        {
            index=i;
            break;
        }
    }

    if(index==-1)
    {
        cout<<"value not found"<<endl;

    }
    else
    {
        for(int i=index; i<*n; i++)
        {
            arr[i]=arr[i+1];
        }
        (*n)--;
    }


    display(arr,*n);
}
int main()
{
    int size;
    cin>>size;
    int arr[size];
    for(int i=0; i<size; i++)
    {
        cin>>arr[i];
    }

    for(int i=0; i<size; i++)
    {
        cout<<arr[i]<<" " ;
    }
    cout<<endl;

    deletebyvalue(arr,&size,3);
}






