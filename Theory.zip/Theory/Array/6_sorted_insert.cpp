#include"iostream"
using namespace std;
void display(int arr[],int n)
{
    for(int i=0; i<n; i++)
    {
        cout<<arr[i]<<" ";
    }
    cout<<endl;
}
void shoertedinsert(int arr[],int &n, int item)
{
    int i;
    for(i=n-1; i>=0; i--)
    {
        if(arr[i]>item)
        {
            arr[i+1]=arr[i];
        }
        else
        {
            break;
        }
        }
        arr[i+1]=item;
        n++;
        display(arr,n);
}

int main()
{
    int size;
    cin>>size;
    int arr[size];
    for(int i=0; i<size; i++)
    {
        cin>>arr[i];
    }

    for(int i=0; i<size; i++)
    {
        cout<<arr[i]<<" " ;
    }
      cout<<endl;

    shoertedinsert(arr,size,0);
    //display(arr,size+1);

    shoertedinsert(arr,size,3);
    //display(arr,size+1);

    shoertedinsert(arr,size,7);
    //display(arr,size+1);
}

