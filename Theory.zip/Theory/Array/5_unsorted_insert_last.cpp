#include"iostream"
using namespace std;
void inserLast(int arr[],int &n, int item)
{
    arr[n]=item;
    n++;
}
void display(int arr[],int n)
{
     for(int i=0; i<n; i++)
    {
        cout<<arr[i]<<" " ;
    }
}
int main()
{
    int size;
    cin>>size;
    int arr[size];
    for(int i=0; i<size; i++)
    {
        cin>>arr[i];
    }

    for(int i=0; i<size; i++)
    {
        cout<<arr[i]<<" " ;
    }
    cout<<endl;
    int item;
    cin>>item;

   inserLast(arr,size+1,item);

   display(arr,size+1);


}

