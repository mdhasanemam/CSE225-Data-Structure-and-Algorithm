#include"iostream"
using namespace std;
bool linearsearch(int arr[],int n,int item)
{
    for(int i=0;i<n;i++)
    {
        if(arr[i]==item)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}
int main()
{
    int size;
    cin>>size;
    int arr[size];
    for(int i=0; i<size; i++)
    {
        cin>>arr[i];
    }

    int item;
    cin>>item;

    bool b= linearsearch(arr,size,item);

    if(b==true)
    {
        cout<<"Item Found"<<endl;
    }
    else
    {
        cout<<"Item not Found"<<endl;

    }

}
