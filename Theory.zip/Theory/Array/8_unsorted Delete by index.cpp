#include"iostream"
using namespace std;
void display(int arr[],int n)
{
    for(int i=0; i<n; i++)
    {
        cout<<arr[i]<<" ";
    }
    cout<<endl;
}

int deletebyindex(int arr[],int *n,int index)
{
   if(index<0||index>=*n)
   {
       cout<<"invalid index"<<endl;

   }
  else{
   arr[index]=arr[*n-1];
   (*n)--;
  }
  display(arr,*n);
}
int main()
{
    int size;
    cin>>size;
    int arr[size];
    for(int i=0; i<size; i++)
    {
        cin>>arr[i];
    }

    for(int i=0; i<size; i++)
    {
        cout<<arr[i]<<" " ;
    }
      cout<<endl;

   deletebyindex(arr,&size,3);
}




