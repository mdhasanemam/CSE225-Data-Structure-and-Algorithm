#include"iostream"
using namespace std;
void display(int arr[],int n)
{
    for(int i=0; i<n; i++)
    {
        cout<<arr[i]<<" ";
    }
    cout<<endl;
}

int deletebyaddres(int arr[],int *n,int index)
{
    if(index<0||index>=*n)
    {
        cout<<"Invalid index"<<endl;
    }
    else
    {
        for(int i=index; i<*n; i++)
        {
            arr[i]=arr[i+1];
        }
        (*n)--;
    }


    display(arr,*n);
}
int main()
{
    int size;
    cin>>size;
    int arr[size];
    for(int i=0; i<size; i++)
    {
        cin>>arr[i];
    }

    for(int i=0; i<size; i++)
    {
        cout<<arr[i]<<" " ;
    }
    cout<<endl;

    deletebyaddres(arr,&size,3);
}

