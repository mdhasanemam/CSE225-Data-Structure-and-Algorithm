#include"iostream"
using namespace std;
void display(int arr[],int n)
{
    for(int i=0; i<n; i++)
    {
        cout<<arr[i]<<" " ;
    }
}
void insertMiddle(int arr[],int &size,int item,int &pos)
{
    for(int i=size; i>pos; i--)
    {
        arr[i]=arr[i-1];
    }
    arr[pos]=item;
    size++;
    display(arr,size);

}

int main()
{
    int size;
    cin>>size;
    int arr[size];
    for(int i=0; i<size; i++)
    {
        cin>>arr[i];
    }

    for(int i=0; i<size; i++)
    {
        cout<<arr[i]<<" " ;
    }
    cout<<endl;
    int item;
    cin>>item;

    int pos;
    cin>>pos;

    insertMiddle(arr,size,item,pos);




}

