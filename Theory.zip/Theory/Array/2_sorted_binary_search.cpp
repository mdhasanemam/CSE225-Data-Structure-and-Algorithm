#include"iostream"
using namespace std;
bool binarysearch(int arr[],int n,int item)
{
    int first=0;
    int last=n-1;
    while(first<=last)
    {
        int middle=(first+last)/2;

        if(arr[middle]==item)
        {
            return true;
        }
        else if(arr[middle]<item)
        {
         first=middle+1;
        }
        else
        {
         last=middle-1;
        }
    }
    return false;
}
int main()
{
    int size;
    cin>>size;
    int arr[size];
    for(int i=0; i<size; i++)
    {
        cin>>arr[i];
    }

    int item;
    cin>>item;

    bool b= binarysearch(arr,size,item);

    if(b==true)
    {
        cout<<"Item Found"<<endl;
    }
    else
    {
        cout<<"Item not Found"<<endl;

    }

}
