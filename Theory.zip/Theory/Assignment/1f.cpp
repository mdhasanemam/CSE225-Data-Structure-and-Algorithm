#include"iostream"
using namespace std;
void display(int arr[],int n)
{
    for(int i=0; i<n; i++)
    {
        cout<<arr[i]<< " ";
    }
    cout<<endl;
}
bool binaraysearch(int arr[],int n,int item)
{
    int f=0,l=n-1;
    while(f<=l)
    {
        int m=(f+l)/2;
        if(arr[m]==item)
        {
            return true;
        }
        else if(arr[m]>item)
        {
            f=m+1;
        }
        else
        {
            l=m-1;
        }

    }
    return false;
}

void deletebyvalue(int arr[],int *n,int item)
{
    int index=-1;
    for(int i=0; i<*n; i++)
    {
        if(arr[i]==item)
        {
            index=i;
            break;
        }
    }
    if(index==-1)
        {
            cout<<"Item is not found"<<endl;
        }
        else
        {
            for(int i=index; i<*n; i++)
            {
                arr[i]=arr[i+1];
            }
            (*n)--;
        }
    display(arr,*n);
}

void insertvalue(int arr[],int &n,int value)
{
    int i;
    for(i=n-1;i>=0;i--)
    {
        if(arr[i]>value)
        {
            arr[i+1]=arr[i];
        }
        else
             {
            break;
        }

    }
    arr[i+1]=value;
    n++;
    display(arr,n);
}
int main()
{
    int n;
    cin>>n;
    int arr[n];

    for(int i=0; i<n; i++)
    {
        cin>>arr[i];
    }
    display(arr,n);

    bool b=binaraysearch(arr,n,21);

    if(b==true)
    {
        cout<<"21 is found"<<endl;
    }
    else
    {
        cout<<"21 is not found"<<endl;
    }

    display(arr,n);
    deletebyvalue(arr,&n,51);
    insertvalue(arr,n,40);

}
