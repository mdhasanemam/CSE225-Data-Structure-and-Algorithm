#include"iostream"
using namespace std;

void display(int arr[],int f,int r,int n)
{
   int i=f;

    while(true)
    {
        cout<<arr[i]<<" ";

        if(i==r)
            break;

        i=(i+1)%n;
    }

    cout<<endl;
}

void enqueue(int arr[],int n,int &f,int &r,int item)
{
    if((r+1)%n==f)
    {
        cout<<"Queue is full"<<endl;
    }
    else if(f==-1)
    {
        f=0;
        r=0;
        arr[r]=item;
    }
    else
    {
        r=(r+1)%n;
        arr[r]=item;
    }
}

void dequeue(int arr[],int n,int &f,int &r)
{
    if(f==-1)
    {
        cout<<"Queue is empty"<<endl;
    }
    else if(f==r)
    {
        f=-1;
        r=-1;
    }
    else
    {
        f=(f+1)%n;
    }
}

int main()
{
    int n;
    cin>>n;
    int arr[n];
    int f=-1,r=-1;
    int x;
    for(int i=0;i<n;i++)
    {
        cin>>x;
        enqueue(arr,n,f,r,x);
    }
    display(arr,f,r,n);
    dequeue(arr,n,f,r);
    display(arr,f,r,n);
    enqueue(arr,n,f,r,99);
    display(arr,f,r,n);
}
