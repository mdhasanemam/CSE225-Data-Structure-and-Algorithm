#include"iostream"
using namespace std;

struct node
{
    char d;
    node* n;
};

void push(node* &t,char x)
{
    node* p=new node;
    p->d=x;
    p->n=t;
    t=p;
}

char pop(node* &t)
{
    char x=t->d;
    node* p=t;
    t=t->n;
    delete p;
   return x;
}

bool check(char a[])
{
    node* t=NULL;

    int c=0;

    while(a[c]!='\0')
    {
        push(t,a[c]);


        c++;
    }

    for(int i=0;i<c;i++)
    {
        if(a[i]!=pop(t))
        {


            return false;
        }
    }



    return true;
}

int main()
{
    char a[100];
cin>>a;
if(check(a))
        cout<<"Palindrome"<<endl;
    else
        cout<<"Not Palindrome"<<endl;
}
