#include"iostream"
using namespace std;
void display(int arr[],int n)
{
    for(int i=0; i<n; i++)
    {
        cout<<arr[i]<<" ";
    }
    cout<<endl;
}

int deletebyvalue(int arr[],int *n,int value)
{
    int index=-1;
    for(int i=0;i<*n;i++)
    {
        if(arr[i]==value)
        {
            index=i;
            break;

        }
    }
    if(index==-1)
    {
        cout<<"Item not found"<<endl;

    }

    arr[index]=arr[*n-1];
    (*n)--;
    display(arr,*n);

}
int main()
{
    int size;
    cin>>size;
    int arr[size];
    for(int i=0; i<size; i++)
    {
        cin>>arr[i];
    }

    for(int i=0; i<size; i++)
    {
        cout<<arr[i]<<" " ;
    }
      cout<<endl;

   deletebyvalue(arr,&size,5);
   //display(arr,size);
}



