#include"iostream"
using namespace std;

struct node
{
    int data;
    node *next;
    node *prev;
};

void display(node *h)
{
    node *t=h;

    while(t!=NULL)
    {
        cout<<t->data<<" ";
        t=t->next;
    }

    cout<<endl;
}

bool searchvalue(node *h,int item)
{
    node *t=h;

    while(t!=NULL)
    {
        if(t->data==item)
        {
            return true;
        }

        t=t->next;
    }

    return false;
}

void deletebyvalue(node *&h,int item)
{
    node *t=h;

    while(t!=NULL)
    {
        if(t->data==item)
        {
            if(t->prev!=NULL)
            {
                t->prev->next=t->next;
            }

            if(t->next!=NULL)
            {
                t->next->prev=t->prev;
            }

            if(t==h)
            {
                h=t->next;
            }

            delete t;
            break;
        }

        t=t->next;
    }

    display(h);
}

void insertvalue(node *h,int value)
{
    node *t=h;

    while(t!=NULL)
    {
        if(t->data==43 && t->next->data==12)
        {
            node *n=new node();

            n->data=value;

            n->next=t->next;
            n->prev=t;

            t->next->prev=n;
            t->next=n;

            break;
        }

        t=t->next;
    }

    display(h);
}

int main()
{
    int n;
    cin>>n;

    node *h=NULL;
    node *t=NULL;

    for(int i=0;i<n;i++)
    {
        int x;
        cin>>x;

        node *n1=new node();

        n1->data=x;
        n1->next=NULL;

        if(h==NULL)
        {
            n1->prev=NULL;
            h=n1;
            t=n1;
        }
        else
        {
            t->next=n1;
            n1->prev=t;
            t=n1;
        }
    }

    display(h);

    bool b=searchvalue(h,12);

    if(b==true)
    {
        cout<<"12 is found"<<endl;
    }
    else
    {
        cout<<"12 is not found"<<endl;
    }

    display(h);

    deletebyvalue(h,99);

    insertvalue(h,40);
}
