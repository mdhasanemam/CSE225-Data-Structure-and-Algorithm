#include"iostream"
using namespace std;

void push(int arr[],int &t,int item)
{
    t++;
    arr[t]=item;
}

int pop(int arr[],int &t)
{
    int x=arr[t];
    t--;
    return x;
}

bool isempty(int t)
{
    if(t==-1)
        return true;
    return false;
}

void enqueue(int a1[],int &t1,int item)
{
    push(a1,t1,item);
}

void dequeue(int a1[],int a2[],int &t1,int &t2)
{
    if(isempty(t1) && isempty(t2))
    {
        cout<<"Queue is empty"<<endl;
        return;
    }

    if(isempty(t2))
    {
        while(!isempty(t1))
        {
            push(a2,t2,pop(a1,t1));
        }
    }

    pop(a2,t2);
}

void front(int a1[],int a2[],int t1,int &t2)
{
    if(isempty(t1) && isempty(t2))
    {
        cout<<"Queue is empty"<<endl;
        return;
    }

    if(isempty(t2))
    {
        while(t1!=-1)
        {
            t2++;
            a2[t2]=a1[t1];
            t1--;
        }
    }

    cout<<a2[t2]<<endl;
}

void display(int a1[],int a2[],int t1,int t2)
{
    for(int i=t2;i>=0;i--)
    {
        cout<<a2[i]<<" ";
    }

    for(int i=0;i<=t1;i++)
    {
        cout<<a1[i]<<" ";
    }

    cout<<endl;
}

int main()
{
    int n;
    cin>>n;
    int a1[n],a2[n];
    int t1=-1,t2=-1;
    int x;

  for(int i=0;i<n;i++)
    {
        cin>>x;
        enqueue(a1,t1,x);
    }

    display(a1,a2,t1,t2);
    front(a1,a2,t1,t2);
    dequeue(a1,a2,t1,t2);
    display(a1,a2,t1,t2);
    if(isempty(t1) && isempty(t2))
        cout<<"Empty"<<endl;
    else
        cout<<"Not Empty"<<endl;
}
