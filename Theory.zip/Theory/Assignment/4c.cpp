#include"iostream"
using namespace std;

int p(char c)
{
    if(c=='+'||c=='-')
        return 1;

    if(c=='*'||c=='/')
        return 2;

    return 0;
}

void push(char arr[],int &t,char x)
{
    t++;
    arr[t]=x;
}

char pop(char arr[],int &t)
{
    char x=arr[t];
    t--;
    return x;
}

void infixtopostfix(char a[],char b[],int n)
{
    char st[n];
    int t=-1,k=0;



    for(int i=0;a[i]!='\0';i++)
    {
        if((a[i]>='A'&&a[i]<='Z')||(a[i]>='a'&&a[i]<='z')||(a[i]>='0'&&a[i]<='9'))
        {
            b[k]=a[i];

            k++;
        }

        else if(a[i]=='(')
        {


            push(st,t,a[i]);
        }

        else if(a[i]==')')
        {
            while(st[t]!='(')
            {
                b[k]=pop(st,t);
                k++;
            }
            pop(st,t);
        }

        else
        {
            while(t!=-1 && p(st[t])>=p(a[i]))
            {
                b[k]=pop(st,t);
                k++;
            }



            push(st,t,a[i]);
        }
    }

    while(t!=-1)
    {
        b[k]=pop(st,t);


        k++;
    }



    b[k]='\0';
}

int main()
{
    char a[100],b[100];
    cin>>a;
    infixtopostfix(a,b,100);
    cout<<b<<endl;
}

